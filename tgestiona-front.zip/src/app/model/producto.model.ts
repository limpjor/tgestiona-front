
export interface ProductoModel
{
   codProducto:string,
   nombre:string,
   precio:string
}