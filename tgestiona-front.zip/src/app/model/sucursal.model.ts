
export interface SucursalModel {
    codSucursal :String,
    nombre:string
}